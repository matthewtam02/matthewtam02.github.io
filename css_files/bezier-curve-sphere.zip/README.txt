A Pen created at CodePen.io. You can find this one at http://codepen.io/matthewtam02/pen/LVPwdN.

 

Forked from [wontem](http://codepen.io/wontem/)'s Pen [Bezier curve sphere](http://codepen.io/wontem/pen/RPbBEW/).