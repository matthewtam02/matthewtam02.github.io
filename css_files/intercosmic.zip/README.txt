A Pen created at CodePen.io. You can find this one at http://codepen.io/matthewtam02/pen/mJbNXw.

 Mouse / Touch  :::  Zoom Into the cosmic sphere && navigate. <br>
Mousemove / Swipe downwards to zoom in. <br>
Mousemove / Swipe upwards to zoom out. <br>
While zoomed in, you can move mouse / swipe to navigate left / right.

Forked from [Tiffany Rayside](http://codepen.io/tmrDevelops/)'s Pen [InterCosmic](http://codepen.io/tmrDevelops/pen/pJzKoM/).