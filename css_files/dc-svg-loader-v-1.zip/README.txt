A Pen created at CodePen.io. You can find this one at http://codepen.io/matthewtam02/pen/dobxmp.

 Pure SVG loading animation. Just my first exploration into SMIL. Very excited when I discovered easing using KeySplines and built in properties like opacity & rotate.

Forked from [Chris Kelley](http://codepen.io/digitalcraft/)'s Pen [DC SVG Loader v.1](http://codepen.io/digitalcraft/pen/JogGyb/).